import argparse
import os.path as osp
import random
import nni
import yaml
from yaml import SafeLoader
import numpy as np
import scipy
import torch
from torch_scatter import scatter_add
import torch.nn as nn
from torch_geometric.utils import dropout_adj, degree, to_undirected, get_laplacian
import torch.nn.functional as F
import networkx as nx
from scipy.sparse.linalg import eigs, eigsh
from torch_geometric.nn import GCNConv
from torch_geometric.utils import get_laplacian, to_scipy_sparse_matrix
from simple_param.sp import SimpleParam
from pGRACE.model import Encoder, GRACE, NewGConv, NewEncoder, NewGRACE
from pGRACE.functional import drop_feature, drop_edge_weighted, \
    degree_drop_weights, \
    evc_drop_weights, pr_drop_weights, \
    feature_drop_weights, drop_feature_weighted_2, feature_drop_weights_dense
from pGRACE.eval import log_regression, MulticlassEvaluator
from pGRACE.utils import get_base_model, get_activation, \
    generate_split, compute_pr, eigenvector_centrality
from pGRACE.dataset import get_dataset
from utils import normalize_adjacency_matrix,  load_adj_neg, Rank,homo_loss,sim
from my_utils import construct_knn_graph, merge_edge_index,get_common_edge_index,get_non_subset_edges,create_adjacency_matrix,cosine_similarity,calculate_cosine_similarity
# import warnings
# warnings.filterwarnings('ignore')

def train():
    model.train()
    #view_learner.eval()
    optimizer.zero_grad()
    edge_index_1 = dropout_adj(data.edge_index, p=preserve_edge_rate_1)[0]
    edge_index_2 = dropout_adj(data.edge_index, p=preserve_edge_rate_2)[0] #adjacency with edge droprate 2
    # drop_edge_1 = get_non_subset_edges(data.edge_index, edge_index_1)#丢掉的边
    # drop_edge_2 = get_non_subset_edges(data.edge_index, edge_index_2)


    # au_edge_index_1, X = construct_knn_graph(data.x, 2)
    # au_edge_index_1 = construct_knn_graph(data.x, 2)
    # au_edge_index_2=construct_knn_graph(data.x,3)
    # common_edge_index_1 = get_common_edge_index(drop_edge_1, au_edge_index_1)
    # common_edge_index_2 = get_common_edge_index(drop_edge_2,au_edge_index_2)


    x_1 = drop_feature(data.x, drop_feature_rate_1)#3
    x_2 = drop_feature(data.x, drop_feature_rate_2)#4

    # edge_index_1 = merge_edge_index(common_edge_index_1, edge_index_1)
    # edge_index_2 = merge_edge_index(common_edge_index_2,edge_index_2)

    drop_weights = pr_drop_weights(data.edge_index).to(device)
    edge_index_1 = drop_edge_weighted(data.edge_index, drop_weights, p=preserve_edge_rate_1, threshold=0.7)
    edge_index_2 = drop_edge_weighted(data.edge_index, drop_weights, p=preserve_edge_rate_2, threshold=0.7)

    # edge_index_ = to_undirected(data.edge_index)
    # node_deg = degree(edge_index_[1])
    # feature_weights = feature_drop_weights(data.x, node_c=node_deg).to(device)
    # x_1 = drop_feature_weighted_2(data.x, feature_weights, drop_feature_rate_1)
    # x_2 = drop_feature_weighted_2(data.x, feature_weights, drop_feature_rate_2)
    # edge_index_1 = edge_index_1.to('cuda:0')
    # edge_index_2 = edge_index_2.to('cuda:0')
    #cora:3,3,6,3
    #CS:(1,2)(1,2)(2,3)(2,3)
    #AP:(3,4)(4,5)(1,2)(2,3)
    #Citseer(2,3)(3,4)(1,2)(1,2)(2,2)
    #CiteSeer(4,2)(3,2)
    #AC:(3,4)(1,4)(0,2)(1,3)
    #PubMed:(0,3)(1,3)(0,3)(0,2)
    #k2 = np.random.randint(0, 4)
    z = model(data.x,data.edge_index,2)
    z1 = model(x_1, edge_index_1, 2)
    z2 = model(x_2, edge_index_2, 3)
    zz = model(data.x,data.edge_index,3)

    adj = create_adjacency_matrix(data.edge_index,data.num_nodes)
    adj1 = create_adjacency_matrix(edge_index_1,data.num_nodes)
    adj2 = create_adjacency_matrix(edge_index_2,data.num_nodes)

    adj = adj.to(args.device)
    adj1 = adj1.to(args.device)
    adj2 = adj2.to(args.device)


    sim1=sim(z1,z1).to(args.device)
    sim2=sim(z2,z2).to(args.device)
    pos1 = torch.where(sim1 > similarity, torch.tensor(1.0, device=args.device), torch.tensor(0.0, device=args.device)) * adj1
    pos2 = torch.where(sim2 > similarity, torch.tensor(1.0, device=args.device), torch.tensor(0.0, device=args.device)) * adj2
    pos1 = pos1.to(args.device)
    pos2 = pos2.to(args.device)

    # sim0 = sim(z, z)
    # sim0 = sim0.to(args.device)
    # pos0 = torch.where(sim0 > 0.7, torch.tensor(1.0, device=args.device), torch.tensor(0.0, device=args.device)) * adj
    # pos0 = pos0.to(args.device)

    # sim00 = sim(zz, zz)
    # sim00 = sim00.to(args.device)
    # pos00 = torch.where(sim00 > 0.7, torch.tensor(1.0, device=args.device), torch.tensor(0.0, device=args.device)) * adj
    # pos00 = pos00.to(args.device)

    # z1 = 0.9*z1+0.1*zz
    # z2 = 0.9*z2+0.1*z
    loss0 = model.loss(z1,pos1, z2,pos2, batch_size=64 if args.dataset == 'Coauthor-Phy' or args.dataset == 'ogbn-arxiv' else None)
    # loss1 = model.loss(zz, pos00, z1, pos1,batch_size=64 if args.dataset == 'Coauthor-Phy' or args.dataset == 'ogbn-arxiv' else None)
    # loss2 = model.loss(z, pos0, z2, pos2,batch_size=64 if args.dataset == 'Coauthor-Phy' or args.dataset == 'ogbn-arxiv' else None)
    loss1 = model.loss1((z+zz)/2,(z1+z2)/2)
    loss2 = model.loss1((z+zz)/2, z1)
    # loss3 = model.loss1((z+zz)/2,z1)
    # loss4 = model.loss1((z + zz) / 2, z2)
    loss = a*loss0+(1-a)*loss1
    loss.backward()
    optimizer.step()

    return loss.item()


def test(final=False):

    model.eval()
    # z1 = model(data.x, data.edge_index, 2)
    # z2 = model(data.x, data.edge_index, 3)
    # z = (z1+z2)/2
    z = model(data.x, data.edge_index,2)

    evaluator = MulticlassEvaluator()
    if args.dataset == 'WikiCS':
        accs = []
        accs_1 = []
        accs_2 = []
        for i in range(20):
            acc = log_regression(z, dataset, evaluator, split=f'wikics:{i}', num_epochs=800)['acc']
            accs.append(acc)
        acc = sum(accs) / len(accs)
    else:
        if args.dataset == 'Cora' or args.dataset == 'CiteSeer' or  args.dataset == 'PubMed':
            acc = log_regression(z, dataset, evaluator, split='preloaded', num_epochs=3000, preload_split=split)['acc']
            # acc = log_regression(z, dataset, evaluator, split='rand:0.2', num_epochs=3000, preload_split=0)['acc']
        else : acc = log_regression(z, dataset, evaluator, split='rand:0.1', num_epochs=3000, preload_split=0)['acc']
        #acc_2 = log_regression(z2, dataset, evaluator2, split='rand:0.1', num_epochs=3000, preload_split=split)['acc']

    if final and use_nni:
        nni.report_final_result(acc)
    elif use_nni:
        nni.report_intermediate_result(acc)

    return acc#, acc_1, acc_2


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', type=str, default='cuda:0')
    parser.add_argument('--dataset', type=str, default='CiteSeer')
    parser.add_argument('--config', type=str, default='param.yaml')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--verbose', type=str, default='train,eval,final')
    parser.add_argument('--save_split', type=str, nargs='?')
    parser.add_argument('--load_split', type=str, nargs='?')
    args = parser.parse_args()

    config = yaml.load(open(args.config), Loader=SafeLoader)[args.dataset]

    torch.manual_seed(args.seed)
    random.seed(0)
    np.random.seed(args.seed)
    # seed = config['seed']
    use_nni = args.config == 'nni'
    learning_rate = config['learning_rate']
    num_hidden = config['num_hidden']
    num_proj_hidden = config['num_proj_hidden']
    activation = config['activation']
    base_model = config['base_model']
    num_layers = config['num_layers']
    dataset = args.dataset
    preserve_edge_rate_1 = config['preserve_edge_rate_1']
    preserve_edge_rate_2 = config['preserve_edge_rate_2']
    drop_feature_rate_1 = config['drop_feature_rate_1']
    drop_feature_rate_2 = config['drop_feature_rate_2']
    drop_scheme = config['drop_scheme']
    tau = config['tau']
    num_epochs = config['num_epochs']
    weight_decay = config['weight_decay']
    rand_layers = config['rand_layers']
    similarity = config['similarity']
    a = config['a']
    device = torch.device(args.device)

    path = osp.expanduser('~/datasets')
    path = osp.join(path, args.dataset)
    dataset = get_dataset(path, args.dataset)
    
    data = dataset[0]
    data = data.to(device)
    adj = 0
    
    if args.dataset == 'Cora' or args.dataset == 'CiteSeer' or  args.dataset == 'PubMed': split = (data.train_mask, data.val_mask, data.test_mask)

    encoder = NewEncoder(dataset.num_features, num_hidden, get_activation(activation),
                      base_model=GCNConv, k=num_layers).to(device)

    model = NewGRACE(encoder, num_hidden, num_proj_hidden, tau).to(device)
    
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=weight_decay
    )   

    log = args.verbose.split(',')

    for epoch in range(1, num_epochs + 1):

        loss = train()
        if 'train' in log:
            print(f'(T) | Epoch={epoch:03d}, loss={loss:.4f}')
        if epoch % 100 == 0:
            acc = test()
            x_1 = drop_feature(data.x, drop_feature_rate_1)#3
            x_2 = drop_feature(data.x, drop_feature_rate_2)#4
            #x_3 = drop_feature(sub_x, drop_feature_rate_1)

            edge_index_2 = dropout_adj(data.edge_index, p=preserve_edge_rate_2)[0] #adjacency with edge droprate 2
            edge_index_1 = dropout_adj(data.edge_index, p=preserve_edge_rate_1)[0] #adjacency with edge droprate 2
            z = model(data.x, data.edge_index,2).detach().cpu().numpy()
            z1 = model(x_1, edge_index_1).detach().cpu().numpy()
            z2 = model(x_2, edge_index_2).detach().cpu().numpy()
            # np.save('embedding/'+args.dataset + 'view1_embeddingfull.npy', z1)
            # np.save('embedding/'+args.dataset + 'view2_embeddingfull.npy', z2)
            # np.save('embedding/'+args.dataset + 'Graph_embeddingfull.npy', z)
            if 'eval' in log:
                print(f'(E) | Epoch={epoch:04d}, avg_acc = {acc}')


    acc = test(final=True)

    if 'final' in log:
        print(f'{acc}')

