# Less is More: Boosting Graph Contrastive Learning via Adaptive Graph Augmentation and Topology-feature-level Homophily # 


For example, to run GCL-GATH under Cora, execute:

    python main.py --device cuda:0 --dataset Cora
    
