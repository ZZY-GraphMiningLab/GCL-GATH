import numpy as np
np.set_printoptions(threshold=np.inf)
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.neighbors import NearestNeighbors
import torch

from typing import Optional, Tuple

import torch

try:
    import torch_cluster  # noqa
    random_walk = torch.ops.torch_cluster.random_walk
except ImportError:
    random_walk = None
from torch import Tensor

from torch_geometric.deprecation import deprecated
from torch_geometric.typing import OptTensor
from torch_geometric.utils.degree import degree
from torch_geometric.utils.num_nodes import maybe_num_nodes
from torch_geometric.utils.sort_edge_index import sort_edge_index
from torch_geometric.utils.subgraph import subgraph

def construct_knn_graph(X, k):
    # 计算节点之间的余弦相似度
    similarities = cosine_similarity(X.cpu().numpy())

    # 使用最近邻算法选择每个节点的 k 个最近邻
    knn = NearestNeighbors(n_neighbors=k+1)  # 加上自身连接
    knn.fit(X.cpu().numpy())
    _, indices = knn.kneighbors(X.cpu().numpy())

    # 构建边的索引
    edges = []
    N = X.shape[0]
    for i in range(N):
        neighbors = indices[i][1:]  # 排除自身连接
        neighbor_similarities = similarities[i, neighbors]
        most_similar_neighbor_idx = neighbors[np.argmax(neighbor_similarities)]
        edges.append([i, most_similar_neighbor_idx])
        edges.append([most_similar_neighbor_idx, i])
    edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()

    return edge_index

# def construct_knn_graph(X):
#     # 计算节点之间的余弦相似度
#     similarities = cosine_similarity(X.cpu().numpy())
#     np.fill_diagonal(similarities, 0)
#     # 构建边的索引
#     edges = []
#     N = X.shape[0]
#     for i in range(N):
#         # 找到与节点 i 最相似的节点
#         most_similar_neighbor_idx = np.argmax(similarities[i])
#         edges.append([i, most_similar_neighbor_idx])
#         edges.append([most_similar_neighbor_idx, i])
#     edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
#
#     return edge_index

# 示例用法
# 假设节点特征矩阵X的形状为 (n_samples, n_features)
# X = torch.randn(100, 10)  # 随机生成一个样例特征矩阵
# k = 3  # 设置最近邻的数量
#
# edge_index= construct_knn_graph(X,2)
#
# print(edge_index)


def merge_edge_index(edge_index1, edge_index2):
    # device = edge_index1.device
    # edge_index2 = edge_index2.to(device)
    edge_index1 = edge_index1.to('cuda:0')
    edge_index2 = edge_index2.to('cuda:0')
    # 合并两个边索引数组
    merged_edge_index = torch.cat((edge_index1, edge_index2), dim=1)

    # 移除重复的边
    merged_edge_index, _ = torch.unique(merged_edge_index, dim=1, sorted=True, return_inverse=True)

    return merged_edge_index


# def get_common_edge_index(edge_index1, edge_index2):
#     edge_index1 = edge_index1.to('cuda:0')
#     edge_index2 = edge_index2.to('cuda:0')
#     common_edges = []
#     for edge in edge_index1.t().tolist():
#         if edge in edge_index2.t().tolist() and edge not in common_edges:
#             common_edges.append(edge)
#     return torch.tensor(common_edges).t()

def get_common_edge_index(edge_index1, edge_index2):
    edge_index1 = edge_index1.to('cuda:0')
    edge_index2 = edge_index2.to('cuda:0')
    set1 = set(map(tuple, edge_index1.t().tolist()))
    set2 = set(map(tuple, edge_index2.t().tolist()))
    common_edges = set1.intersection(set2)
    common_edges = torch.tensor(list(common_edges)).t()
    return common_edges


def get_non_subset_edges(edge_index1, edge_index2):
    edge_index1 = edge_index1.to('cuda:0')
    edge_index2 = edge_index2.to('cuda:0')
    # 将边索引1和边索引2转换为集合
    edge_set1 = set((edge_index1[0, i].item(), edge_index1[1, i].item()) for i in range(edge_index1.size(1)))
    edge_set2 = set((edge_index2[0, i].item(), edge_index2[1, i].item()) for i in range(edge_index2.size(1)))

    # 找到边索引1中不属于边索引2的边
    non_subset_edges = []
    for edge in edge_set1:
        if edge not in edge_set2:
            non_subset_edges.append(edge)

    # 转换为边索引张量
    non_subset_edges = torch.tensor(non_subset_edges).t().contiguous()

    return non_subset_edges

# edge_index1 = torch.tensor([[0, 2, 1, 0, 61] ,[1, 3, 2, 61, 0]])  # 第一个边索引
# edge_index2 = torch.tensor([[3, 2, 4 ,0, 61, 0] ,[4, 3, 0, 1, 0, 61]])  # 第二个边索引
# edge_index3 = torch.tensor([[0, 1, 2], [1, 2, 3]])
# edge_index4 = torch.tensor([[0, 1], [1, 2]])
#
# non_subset_edges = get_non_subset_edges(edge_index1, edge_index2)
#
# merged_edge_index = merge_edge_index(edge_index1, edge_index2)
# common_edge = get_common_edge_index(edge_index1, edge_index2)
# non_subset_edges = get_non_subset_edges(edge_index3, edge_index4)
#
# print(merged_edge_index)
# print(common_edge)
# print(non_subset_edges)

import torch


def create_adjacency_matrix(edge_index, num_nodes):
    """
    Create an adjacency matrix as a PyTorch tensor from edge index.

    Args:
        edge_index (torch.Tensor): Edge index of shape (2, num_edges).
        num_nodes (int): Total number of nodes in the graph.

    Returns:
        torch.Tensor: An adjacency matrix as a PyTorch tensor.
    """
    adj_matrix = torch.zeros((num_nodes, num_nodes), dtype=torch.int32)
    adj_matrix[edge_index[0], edge_index[1]] = 1
    adj_matrix[edge_index[1], edge_index[0]] = 1  # Assuming undirected graph

    return adj_matrix


# Example usage
# edge_index = torch.tensor([[0, 1, 2], [1, 2, 0]])
# num_nodes = 3
# adj_matrix = create_adjacency_matrix(edge_index, num_nodes)
# print(adj_matrix)

import torch

def cosine_similarity(vector_a, vector_b):
    dot_product = torch.dot(vector_a, vector_b)
    norm_a = torch.norm(vector_a)
    norm_b = torch.norm(vector_b)
    similarity = dot_product / (norm_a * norm_b)
    return similarity

# def calculate_cosine_similarity(adjacency_matrix, feature_matrix):
#     num_nodes = adjacency_matrix.size(0)
#     similarity_matrix = torch.zeros_like(adjacency_matrix, dtype=torch.float32)
#
#     for i in range(num_nodes):
#         for j in range(num_nodes):
#             if adjacency_matrix[i, j] == 1:  # Nodes i and j are neighbors
#                 similarity_matrix[i, j] = cosine_similarity(feature_matrix[i], feature_matrix[j])
#
#     return similarity_matrix

def calculate_cosine_similarity(adjacency_matrix, feature_matrix):
    # 将邻接矩阵的对角线元素置为0，确保节点不与自身计算相似度
    # adjacency_matrix = adjacency_matrix.fill_diagonal_(0)

    # 计算节点特征的范数
    norm_matrix = torch.norm(feature_matrix, dim=1, keepdim=True)

    # 计算余弦相似度矩阵
    cosine_sim_matrix = torch.mm(feature_matrix, feature_matrix.t()) / (norm_matrix * norm_matrix.t())

    # 仅保留与邻居节点的相似度
    similarity_matrix = adjacency_matrix * cosine_sim_matrix

    return similarity_matrix
# # 示例邻接矩阵，表示节点之间的连接关系
# adjacency_matrix = torch.tensor([
#     [0, 1, 1],
#     [1, 0, 1],
#     [1, 1, 0]
# ], dtype=torch.int32)
#
# # 示例特征矩阵，每行代表一个节点的特征向量
# feature_matrix = torch.tensor([
#     [1, 2, 3],
#     [4, 5, 6],
#     [7, 8, 9]
# ], dtype=torch.float32)
#
# similarity_matrix = calculate_cosine_similarity(adjacency_matrix, feature_matrix)
# print("Cosine Similarity Matrix for Neighbor Nodes:")
# print(similarity_matrix)














